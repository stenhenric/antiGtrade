/**
 * AntiGTrade — Antigravity / VS Code Extension
 * Opens a live OKX trading dashboard as a webview panel.
 * No proxy server needed — WebSocket connects directly to OKX.
 */

const vscode = require('vscode');
const path   = require('path');
const fs     = require('fs');
const crypto = require('crypto');

let panel = null;

function getDashboardHtml(context) {
  const dashPath = path.join(context.extensionPath, 'dashboard.html');

  let html;
  try {
    html = fs.readFileSync(dashPath, 'utf8');
  } catch (e) {
    return `<!DOCTYPE html><html><body style="background:#000;color:#00d26a;font-family:monospace;padding:32px;">
      <h2>AntiGTrade</h2><p style="color:#888;margin-top:8px;">Could not load dashboard: ${e.message}</p>
    </body></html>`;
  }

  // Generate a nonce so VS Code trusts our inline script
  const nonce = crypto.randomBytes(16).toString('base64');

  // Inject nonce into the <script> tag
  html = html.replace('<script>', `<script nonce="${nonce}">`);

  // Remove any existing CSP meta tags
  html = html.replace(/<meta http-equiv="Content-Security-Policy"[^>]*>/gi, '');

  // Inject CSP — direct WebSocket + REST to OKX, no proxy needed
  const csp = [
    `default-src 'none'`,
    `script-src 'nonce-${nonce}'`,
    `style-src 'unsafe-inline'`,
    `connect-src wss://ws.okx.com:8443 https://www.okx.com`,
    `img-src data:`,
  ].join('; ');

  html = html.replace('<head>', `<head>\n<meta http-equiv="Content-Security-Policy" content="${csp}">`);

  return html;
}

function openPanel(context) {
  if (panel) {
    panel.reveal(vscode.ViewColumn.Two);
    return;
  }

  panel = vscode.window.createWebviewPanel(
    'antigtrade',
    'AntiGTrade',
    vscode.ViewColumn.Two,
    {
      enableScripts: true,
      retainContextWhenHidden: true,
    }
  );

  panel.webview.html = getDashboardHtml(context);
  panel.onDidDispose(() => { panel = null; }, null, context.subscriptions);
}

function activate(context) {
  openPanel(context);
  const cmd = vscode.commands.registerCommand('antigtrade.open', () => openPanel(context));
  context.subscriptions.push(cmd);
}

function deactivate() {}

module.exports = { activate, deactivate };
