# AntiGTrade for Antigravity IDE

Live OKX trading dashboard — runs as a panel inside Antigravity.

## Install

1. Open Antigravity IDE
2. Press `Ctrl+Shift+P` → "Extensions: Install from VSIX"
3. Select `antigtrade-1.0.0.vsix`
4. The dashboard opens automatically

## Usage

- **Reopen:** `Ctrl+Shift+T` or Command Palette → "Open AntiGTrade Dashboard"
- **Trade via AI:** Use the Antigravity chat with OKX MCP configured

## OKX MCP Setup (for AI trading)

Add to your Antigravity MCP config:

```json
{
  "mcpServers": {
    "okx-trade": {
      "command": "npx",
      "args": ["-y", "okx-trade-mcp", "--demo"],
      "env": {
        "OKX_API_KEY": "your_key",
        "OKX_SECRET_KEY": "your_secret",
        "OKX_PASSPHRASE": "your_passphrase"
      }
    }
  }
}
```

## Requirements

- Node.js 18+ (for the built-in proxy server)
- Antigravity IDE (or any VS Code fork)
